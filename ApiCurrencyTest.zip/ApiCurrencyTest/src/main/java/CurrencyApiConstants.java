


    public class CurrencyApiConstants {
        public static final String BASE_URL = "https://api.apilayer.com/currency_data";
        public static final String API_KEY = "dMbWnhnVv3F8mhYxej36q1bqND5K6WDp";
    }
