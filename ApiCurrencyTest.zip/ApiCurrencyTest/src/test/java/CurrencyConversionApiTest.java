import io.restassured.response.Response;
import static io.restassured.RestAssured.*;

import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class CurrencyConversionApiTest {

//    @Test
//    public void responceCodeTest(){
//
//        Response response = given().get(CurrencyApiConstants.BASE_URL+CurrencyApiConstants.API_KEY);
//        System.out.println(response.asString());
//
//    }
@Test
public void responceCodeTest() {
    String baseURL = CurrencyApiConstants.BASE_URL;
    String apiKey = CurrencyApiConstants.API_KEY;

    Response response = given()
            .baseUri(baseURL)
            .queryParam("apikey", apiKey)
            .when()
            .get("/live");

    System.out.println(response.asString());
}
    @Test
    public void testCurrencyConversionApi() {

        String baseURL = CurrencyApiConstants.BASE_URL;
        String apiKey = CurrencyApiConstants.API_KEY;


        String endpoint = "/live";


        String sourceCurrency = "USD";
        String currencies = "EUR,GBP,JPY";


        Response response = given()
                .baseUri(baseURL)
                .basePath(endpoint)
                .queryParam("apikey", apiKey)
                .queryParam("source", sourceCurrency)
                .queryParam("currencies", currencies)
                .when()
                .get();


        System.out.println("Response Status Code: " + response.getStatusCode());


        response.then().statusCode(200);
        response.then().body("success", equalTo(true));
        response.then().body("terms", notNullValue());
        response.then().body("privacy", notNullValue());
        response.then().body("timestamp", notNullValue());
        response.then().body("source", equalTo(sourceCurrency));
        response.then().body("quotes.USDEUR", notNullValue());
        response.then().body("quotes.USDGBP", notNullValue());
        response.then().body("quotes.USDJPY", notNullValue());

    }
}